package com.example.s70712_lab2_task4

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.s70712_lab2_task4.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // 2.1 Track validation states (Already present)
    private var isEmailValid = false
    private var isPasswordValid = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 2.1 Disable button until form valid
        binding.btnCreate.isEnabled = false // Start with btnCreate.isEnabled = false

        // Exposed dropdown (AutoCompleteTextView)
        val interests = resources.getStringArray(R.array.interests)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, interests)
        binding.actvInterest.setAdapter(adapter)

        // 2.2 Dynamic Hint logic (Use a checked change listener for the switch)
        binding.swNewsletter.setOnCheckedChangeListener { _, isChecked ->
            // Dynamic hint: Change hint when switch is ON, otherwise revert.
            binding.tilEmail.hint = if (isChecked) {
                "Email for newsletter"
            } else {
                getString(R.string.label_email) // Assumes R.string.label_email is available
            }
        }

        // Email validation (inline TextWatcher)
        binding.edtEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val email = s?.trim()?.toString().orEmpty()
                val isValid = email.isNotEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches()

                // 2.2 Update Email validation and error message
                binding.tilEmail.error = if (isValid) null
                else if (email.isNotEmpty()) "Invalid email format"
                else null

                isEmailValid = isValid
                updateButtonState() // Update button state
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Password validation (inline TextWatcher)
        binding.edtPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val pass = s?.trim()?.toString().orEmpty()
                val length = pass.length

                // 2.3 Password Strength Logic
                val strengthText: String
                val strengthColor: Int

                if (length == 0) {
                    strengthText = ""
                    strengthColor = getColor(android.R.color.transparent)
                    binding.tilPassword.error = null
                } else if (length < 6) {
                    strengthText = "Weak"
                    strengthColor = getColor(android.R.color.holo_red_dark)
                    binding.tilPassword.error = "Password too short"
                } else if (length < 10) {
                    strengthText = "OK"
                    strengthColor = getColor(android.R.color.holo_orange_dark)
                    binding.tilPassword.error = null
                } else {
                    strengthText = "Strong"
                    strengthColor = getColor(android.R.color.holo_green_dark)
                    binding.tilPassword.error = null
                }

                // Set the strength text and color (assumes tvPasswordStrength ID exists in layout)
                binding.tvPasswordStrength.text = strengthText
                binding.tvPasswordStrength.setTextColor(strengthColor)

                isPasswordValid = length >= 6
                updateButtonState() // Update button state
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // SeekBar changes preview text size (inline listener)
        binding.seekTextSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                val size = if (value < 10) 10 else value
                binding.tvPreview.textSize = size.toFloat()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // 2.4 Button click logic update
        binding.btnCreate.setOnClickListener {
            // Since the button is only enabled when email and password are valid,
            // we only need to check the interest field here.

            val email = binding.edtEmail.text?.toString()?.trim().orEmpty()
            val pass = binding.edtPassword.text?.toString()?.trim().orEmpty()
            val interest = binding.actvInterest.text?.toString()?.trim().orEmpty()
            val newsletter = if (binding.swNewsletter.isChecked) "Yes" else "No"

            val interestOK = interest.isNotEmpty()

            // Interest required validation
            binding.tilInterest.error = if (interestOK) null else "Please select an interest"

            if (interestOK) {
                // Account Created
                binding.tvResult.text = """ 
                    *** Account Created ***
                    Email: $email
                    Interest: $interest
                    Newsletter: $newsletter
                    *** End ***
                """.trimIndent()

                Toast.makeText(this, "Welcome!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 2.1 Helper function for button state (moved outside of onCreate)
    private fun updateButtonState() {
        // Enable when both fields pass validation.
        binding.btnCreate.isEnabled = isEmailValid && isPasswordValid
    }
}